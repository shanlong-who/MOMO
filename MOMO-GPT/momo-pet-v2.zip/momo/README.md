# MOMO chat-app pet assets

This package contains the original MOMO v2 pet manifest and WebP animation sheet.
The artwork is a silver tabby cat with amber eyes and a teal collar.

Files:
- pet.json: pet manifest with spriteVersionNumber 2.
- spritesheet.webp: 1536 x 2288 animation atlas, with 8 columns and 11 rows.
- LICENSE: MIT license for the included project files and generated artwork.

These assets are for the chat-app pet version of MOMO. For an independent
Windows desktop cat running in local R, use the MOMO-Offline or MIMI-Offline
folder from https://github.com/shanlong-who/MOMO.

Local build reports and personal paths are omitted from this public package.
